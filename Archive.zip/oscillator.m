    clear;
    clf;
   

    %%% Initial conditions %%%
    initX = pi/4;
    initV = 5;
    mass = 1;
    length = 1;
    dampC = 0.5;

    vNow = initV;
    xNow = initX;
    timeNow = 0;

    %%% Time handling %%%
    totalTime = 10*2*pi; %Total time to simulate
    N = 10000; % Number of simulation steps (more = more accuracy)
    delT = totalTime/N;  %Time for each time step

    %%% Arrays to store time points and associated x values %%%
    tSteps = [];
    xSteps = [];
    vSteps = [];
    dispSteps = [];
    pxSteps = [];
    pySteps = [];
    
    %%% main "for" loop - do N steps if simulation %%%%
    for step = 1:1:N, 
        fNow = calcForce(mass, xNow);   % calculate force at point x
        damping = dampC*vNow;
        fNow  = fNow - damping;
        aNow = calcAccel(fNow,mass,length);   % calculate acceleration at point x
        
        xNow = xNow + calcDeltaX(vNow,aNow,delT);   % update x (location)
        vNow = vNow + calcDeltaV(aNow,delT);   % update velocity
        timeNow = timeNow+delT;    % update time
        
        tSteps = [tSteps, timeNow];  % store current time for plotting
        xSteps = [xSteps, xNow];  % store current location for plotting
        vSteps = [vSteps, vNow];
        dispNow = length*xNow;
        dispSteps = [dispSteps, dispNow];
        pxSteps = [pxSteps, length * sin(xNow)];
        pySteps = [pySteps, -(length * cos(xNow))];
      
    end
    
    figure;
    subplot(2,2,1);
    plot(xSteps,vSteps);
    title(["Phase Space: initx = " num2str(initX)]);
    
    subplot(2,2,2);
    plot(pxSteps, pySteps);
    title(["Location Plot: initv = " num2str(initV)]);
    
    subplot(2,2,3);
    plot(vSteps, tSteps);
    title(['V over time: time = ' num2str(totalTime)]);
    
    subplot(2,2,4);
    plot(dispSteps, tSteps);
    title(['Displacement over Time: damping = ' num2str(dampC)]);
    
    print Damped_initial_driving_force.pdf
    
    NvSteps = gradient(xSteps)/delT;
    NaSteps = gradient(NvSteps)/delT;
 
    %%%   See what you have done here
    %figure;
    %         plot(tSteps,xSteps);
    %     quiver(xSteps,zeros(size(xSteps)), vSteps, zeros(size(vSteps)))
    %     quiver(xSteps, xSteps, vSteps, vSteps);
    %     drawnow;
    %     pause










