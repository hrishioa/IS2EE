function F = calcForce(m, x)
    % Take current x coordinate and return force acting on mass
    damper = 0.5;
    F = -m*9.81*sin(x);
end