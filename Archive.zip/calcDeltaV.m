function delV = calcDeltaV(aNow,delT)
    % Take force and current velocity and calculate difference in speed deltaT
    delV = aNow*delT;
end